﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BookBizMS.BLL
{
    public  class BookAuthor
    {
        public int BookID 
            { get; set; }
        public int AuthorID
            { get; set; }                       
    }
}
